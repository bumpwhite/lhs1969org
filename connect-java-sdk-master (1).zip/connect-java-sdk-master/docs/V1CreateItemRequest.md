
# V1CreateItemRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**V1Item**](V1Item.md) | An object containing the fields to POST for the request.  See the corresponding object definition for field details. |  [optional]



