
# V1CreateEmployeeRoleRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**employeeRole** | [**V1EmployeeRole**](V1EmployeeRole.md) | An EmployeeRole object with a name and permissions, and an optional owner flag. |  [optional]



