
# V1DiscountColor

## Enum


* `_9DA2A6` (value: `"9da2a6"`)

* `_4AB200` (value: `"4ab200"`)

* `_0B8000` (value: `"0b8000"`)

* `_2952CC` (value: `"2952cc"`)

* `A82EE5` (value: `"a82ee5"`)

* `E5457A` (value: `"e5457a"`)

* `B21212` (value: `"b21212"`)

* `_593C00` (value: `"593c00"`)

* `E5BF00` (value: `"e5BF00"`)



