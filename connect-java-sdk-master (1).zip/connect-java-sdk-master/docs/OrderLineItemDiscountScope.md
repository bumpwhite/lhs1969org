
# OrderLineItemDiscountScope

## Enum


* `OTHER_DISCOUNT_SCOPE` (value: `"OTHER_DISCOUNT_SCOPE"`)

* `LINE_ITEM` (value: `"LINE_ITEM"`)

* `ORDER` (value: `"ORDER"`)



