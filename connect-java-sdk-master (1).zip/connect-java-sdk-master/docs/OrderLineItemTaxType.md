
# OrderLineItemTaxType

## Enum


* `UNKNOWN_TAX` (value: `"UNKNOWN_TAX"`)

* `ADDITIVE` (value: `"ADDITIVE"`)

* `INCLUSIVE` (value: `"INCLUSIVE"`)



