
# GetBreakTypeRequest

### Description

A request to GET a `BreakType` by ID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



