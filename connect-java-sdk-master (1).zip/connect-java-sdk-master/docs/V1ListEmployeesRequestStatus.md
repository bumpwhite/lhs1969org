
# V1ListEmployeesRequestStatus

## Enum


* `ACTIVE` (value: `"ACTIVE"`)

* `INACTIVE` (value: `"INACTIVE"`)



