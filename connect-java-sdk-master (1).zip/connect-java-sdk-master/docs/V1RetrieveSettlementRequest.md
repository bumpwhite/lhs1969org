
# V1RetrieveSettlementRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



