
# CatalogObjectType

## Enum


* `ITEM` (value: `"ITEM"`)

* `CATEGORY` (value: `"CATEGORY"`)

* `ITEM_VARIATION` (value: `"ITEM_VARIATION"`)

* `TAX` (value: `"TAX"`)

* `DISCOUNT` (value: `"DISCOUNT"`)

* `MODIFIER_LIST` (value: `"MODIFIER_LIST"`)

* `MODIFIER` (value: `"MODIFIER"`)



