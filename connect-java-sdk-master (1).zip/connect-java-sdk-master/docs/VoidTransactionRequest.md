
# VoidTransactionRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



