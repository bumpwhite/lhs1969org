
# V1DeleteDiscountRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



