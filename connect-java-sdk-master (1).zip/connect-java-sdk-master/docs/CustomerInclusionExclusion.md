
# CustomerInclusionExclusion

## Enum


* `INCLUDE` (value: `"INCLUDE"`)

* `EXCLUDE` (value: `"EXCLUDE"`)



