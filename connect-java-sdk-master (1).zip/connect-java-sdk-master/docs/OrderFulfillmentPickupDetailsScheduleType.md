
# OrderFulfillmentPickupDetailsScheduleType

## Enum


* `SCHEDULED` (value: `"SCHEDULED"`)

* `ASAP` (value: `"ASAP"`)



