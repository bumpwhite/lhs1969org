
# V1DeleteItemRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



