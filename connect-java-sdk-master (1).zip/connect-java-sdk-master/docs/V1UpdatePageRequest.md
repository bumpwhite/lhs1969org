
# V1UpdatePageRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**V1Page**](V1Page.md) | An object containing the fields to POST for the request.  See the corresponding object definition for field details. | 



