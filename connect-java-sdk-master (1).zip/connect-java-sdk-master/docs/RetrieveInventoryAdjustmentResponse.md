
# RetrieveInventoryAdjustmentResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**List&lt;Error&gt;**](Error.md) | Any errors that occurred during the request. |  [optional]
**adjustment** | [**InventoryAdjustment**](InventoryAdjustment.md) | The requested [InventoryAdjustment](#type-inventoryadjustment). |  [optional]



