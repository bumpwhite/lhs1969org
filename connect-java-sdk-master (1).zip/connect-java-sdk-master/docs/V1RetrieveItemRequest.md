
# V1RetrieveItemRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



