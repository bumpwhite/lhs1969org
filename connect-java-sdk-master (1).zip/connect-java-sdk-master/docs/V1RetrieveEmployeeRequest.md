
# V1RetrieveEmployeeRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



