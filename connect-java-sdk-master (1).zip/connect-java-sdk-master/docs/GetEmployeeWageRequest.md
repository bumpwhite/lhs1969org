
# GetEmployeeWageRequest

### Description

A request to get an `EmployeeWage`

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



