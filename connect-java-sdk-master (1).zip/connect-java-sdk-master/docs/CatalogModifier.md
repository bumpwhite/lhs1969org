
# CatalogModifier

### Description

A modifier in the Catalog object model.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The modifier&#39;s name. Searchable. This field has max length of 255 Unicode code points. |  [optional]
**priceMoney** | [**Money**](Money.md) | The modifier&#39;s price. |  [optional]



