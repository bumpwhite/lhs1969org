
# CatalogQueryPrefix

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attributeName** | **String** | The name of the attribute to be searched. | 
**attributePrefix** | **String** | The desired prefix of the search attribute value. | 



