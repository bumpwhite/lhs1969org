
# V1RemoveFeeRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



