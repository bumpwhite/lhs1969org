
# GetShiftRequest

### Description

A request to get a `Shift` by ID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



