
# V1ListCategoriesResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Category&gt;**](V1Category.md) |  |  [optional]



