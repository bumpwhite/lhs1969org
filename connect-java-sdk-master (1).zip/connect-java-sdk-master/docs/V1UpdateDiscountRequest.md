
# V1UpdateDiscountRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**V1Discount**](V1Discount.md) | An object containing the fields to POST for the request.  See the corresponding object definition for field details. | 



