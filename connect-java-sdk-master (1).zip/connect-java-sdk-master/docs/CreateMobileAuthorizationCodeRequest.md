
# CreateMobileAuthorizationCodeRequest

### Description

Defines the body parameters that can be provided in a request to the [CreateMobileAuthorizationCode](#endpoint-createmobileauthorizationcode) endpoint.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**locationId** | **String** | The Square location ID the authorization code should be tied to. |  [optional]



