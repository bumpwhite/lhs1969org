
# V1ListRefundsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Refund&gt;**](V1Refund.md) |  |  [optional]



