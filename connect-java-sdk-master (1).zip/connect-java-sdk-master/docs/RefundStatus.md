
# RefundStatus

## Enum


* `PENDING` (value: `"PENDING"`)

* `APPROVED` (value: `"APPROVED"`)

* `REJECTED` (value: `"REJECTED"`)

* `FAILED` (value: `"FAILED"`)



