
# V1OrderHistoryEntryAction

## Enum


* `ORDER_PLACED` (value: `"ORDER_PLACED"`)

* `DECLINED` (value: `"DECLINED"`)

* `PAYMENT_RECEIVED` (value: `"PAYMENT_RECEIVED"`)

* `CANCELED` (value: `"CANCELED"`)

* `COMPLETED` (value: `"COMPLETED"`)

* `REFUNDED` (value: `"REFUNDED"`)

* `EXPIRED` (value: `"EXPIRED"`)



