
# V1DeleteTimecardRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



