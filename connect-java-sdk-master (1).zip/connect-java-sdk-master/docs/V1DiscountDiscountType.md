
# V1DiscountDiscountType

## Enum


* `FIXED` (value: `"FIXED"`)

* `VARIABLE_PERCENTAGE` (value: `"VARIABLE_PERCENTAGE"`)

* `VARIABLE_AMOUNT` (value: `"VARIABLE_AMOUNT"`)



