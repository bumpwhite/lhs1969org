
# CatalogQueryRange

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attributeName** | **String** | The name of the attribute to be searched. | 
**attributeMinValue** | **Long** | The desired minimum value for the search attribute (inclusive). |  [optional]
**attributeMaxValue** | **Long** | The desired maximum value for the search attribute (inclusive). |  [optional]



