
# InventoryChangeType

## Enum


* `PHYSICAL_COUNT` (value: `"PHYSICAL_COUNT"`)

* `ADJUSTMENT` (value: `"ADJUSTMENT"`)

* `TRANSFER` (value: `"TRANSFER"`)



