
# V1ListFeesResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Fee&gt;**](V1Fee.md) |  |  [optional]



