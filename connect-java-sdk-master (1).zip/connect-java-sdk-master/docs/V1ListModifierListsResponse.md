
# V1ListModifierListsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1ModifierList&gt;**](V1ModifierList.md) |  |  [optional]



