
# CatalogQueryItemsForTax

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taxIds** | **List&lt;String&gt;** | A set of [CatalogTax](#type-catalogtax) IDs to be used to find associated [CatalogItem](#type-catalogitem)s. | 



