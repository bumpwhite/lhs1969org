
# V1CashDrawerShiftEventType

## Enum


* `OPEN` (value: `"OPEN"`)

* `ENDED` (value: `"ENDED"`)

* `CLOSED` (value: `"CLOSED"`)



