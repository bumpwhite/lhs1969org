
# CustomerGroupInfo

### Description

Contains some brief information about a customer group with its identifier included.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The ID of the customer group. | 
**name** | **String** | The name of the customer group. | 



