
# RetrieveTransactionRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



