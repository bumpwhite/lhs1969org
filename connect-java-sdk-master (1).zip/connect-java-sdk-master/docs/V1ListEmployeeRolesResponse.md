
# V1ListEmployeeRolesResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1EmployeeRole&gt;**](V1EmployeeRole.md) |  |  [optional]



