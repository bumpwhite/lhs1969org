
# V1ListTimecardsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Timecard&gt;**](V1Timecard.md) |  |  [optional]



