
# CustomerSortField

## Enum


* `DEFAULT` (value: `"DEFAULT"`)

* `CREATED_AT` (value: `"CREATED_AT"`)



