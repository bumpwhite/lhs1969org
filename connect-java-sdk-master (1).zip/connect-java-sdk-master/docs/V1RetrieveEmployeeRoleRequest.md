
# V1RetrieveEmployeeRoleRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



