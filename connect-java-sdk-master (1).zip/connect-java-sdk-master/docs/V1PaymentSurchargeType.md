
# V1PaymentSurchargeType

## Enum


* `UNKNOWN` (value: `"UNKNOWN"`)

* `AUTO_GRATUITY` (value: `"AUTO_GRATUITY"`)

* `CUSTOM` (value: `"CUSTOM"`)



