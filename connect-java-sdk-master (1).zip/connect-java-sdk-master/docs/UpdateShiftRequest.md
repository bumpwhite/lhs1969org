
# UpdateShiftRequest

### Description

A request to update a `Shift` object.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shift** | [**Shift**](Shift.md) | The updated &#x60;Shift&#x60; object. | 



