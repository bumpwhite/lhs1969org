
# V1RetrieveBankAccountRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



