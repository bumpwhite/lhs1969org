
# InventoryAlertType

## Enum


* `NONE` (value: `"NONE"`)

* `LOW_QUANTITY` (value: `"LOW_QUANTITY"`)



