
# V1ListSettlementsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Settlement&gt;**](V1Settlement.md) |  |  [optional]



