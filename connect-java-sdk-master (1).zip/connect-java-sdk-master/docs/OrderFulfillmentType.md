
# OrderFulfillmentType

## Enum


* `PICKUP` (value: `"PICKUP"`)



