
# CatalogObjectBatch

### Description

A batch of [CatalogObject](#type-catalogobject)s.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**objects** | [**List&lt;CatalogObject&gt;**](CatalogObject.md) | A list of [CatalogObject](#type-catalogobject)s belonging to this batch. |  [optional]



