
# V1DeleteTimecardResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



