
# ShiftSortField

## Enum


* `START_AT` (value: `"START_AT"`)

* `END_AT` (value: `"END_AT"`)

* `CREATED_AT` (value: `"CREATED_AT"`)

* `UPDATED_AT` (value: `"UPDATED_AT"`)



