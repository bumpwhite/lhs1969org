
# V1MerchantAccountType

## Enum


* `LOCATION` (value: `"LOCATION"`)

* `BUSINESS` (value: `"BUSINESS"`)



