
# V1ListBankAccountsRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



