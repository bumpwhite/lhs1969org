
# V1TenderEntryMethod

## Enum


* `MANUAL` (value: `"MANUAL"`)

* `SCANNED` (value: `"SCANNED"`)

* `SQUARE_CASH` (value: `"SQUARE_CASH"`)

* `SQUARE_WALLET` (value: `"SQUARE_WALLET"`)

* `SWIPED` (value: `"SWIPED"`)

* `WEB_FORM` (value: `"WEB_FORM"`)

* `OTHER` (value: `"OTHER"`)



