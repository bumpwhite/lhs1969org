
# V1RetrievePaymentRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



