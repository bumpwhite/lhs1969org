
# V1RefundType

## Enum


* `FULL` (value: `"FULL"`)

* `PARTIAL` (value: `"PARTIAL"`)



