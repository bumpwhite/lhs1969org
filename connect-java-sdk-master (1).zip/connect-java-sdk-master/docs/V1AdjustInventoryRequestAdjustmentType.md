
# V1AdjustInventoryRequestAdjustmentType

## Enum


* `SALE` (value: `"SALE"`)

* `RECEIVE_STOCK` (value: `"RECEIVE_STOCK"`)

* `MANUAL_ADJUST` (value: `"MANUAL_ADJUST"`)



