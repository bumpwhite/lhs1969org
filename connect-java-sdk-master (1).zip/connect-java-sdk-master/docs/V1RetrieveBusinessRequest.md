
# V1RetrieveBusinessRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



