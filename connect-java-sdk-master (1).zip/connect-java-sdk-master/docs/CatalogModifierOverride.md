
# CatalogModifierOverride

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modifierId** | **String** | The ID of the [CatalogModifier](#type-catalogmodifier) whose default behavior is being overridden. | 
**onByDefault** | **Boolean** | If &#x60;true&#x60;, this [CatalogModifier](#type-catalogmodifier) should be selected by default for this [CatalogItem](#type-catalogitem). |  [optional]



