
# V1UpdateEmployeeRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**V1Employee**](V1Employee.md) | An object containing the fields to POST for the request.  See the corresponding object definition for field details. | 



