
# CatalogQueryText

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keywords** | **List&lt;String&gt;** | A list of one, two, or three search keywords. Keywords with fewer than three characters are ignored. | 



