
# V1UpdateModifierListRequestSelectionType

## Enum


* `SINGLE` (value: `"SINGLE"`)

* `MULTIPLE` (value: `"MULTIPLE"`)



