
# V1CreateCategoryRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**V1Category**](V1Category.md) | An object containing the fields to POST for the request.  See the corresponding object definition for field details. |  [optional]



