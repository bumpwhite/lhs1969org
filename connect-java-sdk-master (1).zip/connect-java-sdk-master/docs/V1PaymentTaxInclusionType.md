
# V1PaymentTaxInclusionType

## Enum


* `ADDITIVE` (value: `"ADDITIVE"`)

* `INCLUSIVE` (value: `"INCLUSIVE"`)



