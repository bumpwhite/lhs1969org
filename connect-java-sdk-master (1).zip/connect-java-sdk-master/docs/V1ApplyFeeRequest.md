
# V1ApplyFeeRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



