
# DeleteShiftRequest

### Description

A request to delete a `Shift`

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



