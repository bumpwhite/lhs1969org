
# V1ListEmployeesResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Employee&gt;**](V1Employee.md) |  |  [optional]



