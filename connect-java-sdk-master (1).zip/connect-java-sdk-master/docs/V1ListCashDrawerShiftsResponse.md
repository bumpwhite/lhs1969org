
# V1ListCashDrawerShiftsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1CashDrawerShift&gt;**](V1CashDrawerShift.md) |  |  [optional]



