
# V1DeleteFeeRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



