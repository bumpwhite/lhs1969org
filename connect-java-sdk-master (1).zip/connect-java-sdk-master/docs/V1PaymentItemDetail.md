
# V1PaymentItemDetail

### Description

V1PaymentItemDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categoryName** | **String** | The name of the item&#39;s merchant-defined category, if any. |  [optional]
**sku** | **String** |  The item&#39;s merchant-defined SKU, if any. |  [optional]
**itemId** | **String** | The unique ID of the item purchased, if any. |  [optional]
**itemVariationId** | **String** | The unique ID of the item variation purchased, if any. |  [optional]



