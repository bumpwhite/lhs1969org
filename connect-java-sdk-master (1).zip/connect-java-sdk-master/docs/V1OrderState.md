
# V1OrderState

## Enum


* `PENDING` (value: `"PENDING"`)

* `OPEN` (value: `"OPEN"`)

* `COMPLETED` (value: `"COMPLETED"`)

* `CANCELED` (value: `"CANCELED"`)

* `REFUNDED` (value: `"REFUNDED"`)

* `REJECTED` (value: `"REJECTED"`)



