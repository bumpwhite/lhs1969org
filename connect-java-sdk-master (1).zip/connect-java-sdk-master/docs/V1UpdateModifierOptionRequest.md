
# V1UpdateModifierOptionRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**V1ModifierOption**](V1ModifierOption.md) | An object containing the fields to POST for the request.  See the corresponding object definition for field details. | 



