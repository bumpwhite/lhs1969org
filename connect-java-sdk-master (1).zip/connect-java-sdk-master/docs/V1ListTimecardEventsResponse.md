
# V1ListTimecardEventsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1TimecardEvent&gt;**](V1TimecardEvent.md) |  |  [optional]



