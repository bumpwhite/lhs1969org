
# V1FeeAdjustmentType

## Enum


* `TAX` (value: `"TAX"`)



