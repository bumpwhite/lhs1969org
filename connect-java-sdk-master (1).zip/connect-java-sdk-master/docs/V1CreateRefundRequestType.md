
# V1CreateRefundRequestType

## Enum


* `FULL` (value: `"FULL"`)

* `PARTIAL` (value: `"PARTIAL"`)



