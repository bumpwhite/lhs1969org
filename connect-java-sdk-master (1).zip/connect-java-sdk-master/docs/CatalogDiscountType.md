
# CatalogDiscountType

## Enum


* `FIXED_PERCENTAGE` (value: `"FIXED_PERCENTAGE"`)

* `FIXED_AMOUNT` (value: `"FIXED_AMOUNT"`)

* `VARIABLE_PERCENTAGE` (value: `"VARIABLE_PERCENTAGE"`)

* `VARIABLE_AMOUNT` (value: `"VARIABLE_AMOUNT"`)



