
# V1ListInventoryResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1InventoryEntry&gt;**](V1InventoryEntry.md) |  |  [optional]



