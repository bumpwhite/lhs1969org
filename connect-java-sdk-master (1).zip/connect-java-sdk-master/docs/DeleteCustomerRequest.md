
# DeleteCustomerRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



