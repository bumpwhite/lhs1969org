
# V1ListCategoriesRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



