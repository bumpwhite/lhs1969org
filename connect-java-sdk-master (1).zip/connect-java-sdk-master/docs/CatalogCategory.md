
# CatalogCategory

### Description

A category to which an [CatalogItem](#type-catalogitem) belongs in the Catalog object model.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The category&#39;s name. Searchable. This field has max length of 255 Unicode code points. |  [optional]



