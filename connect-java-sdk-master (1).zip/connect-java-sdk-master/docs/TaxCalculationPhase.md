
# TaxCalculationPhase

## Enum


* `SUBTOTAL_PHASE` (value: `"TAX_SUBTOTAL_PHASE"`)

* `TOTAL_PHASE` (value: `"TAX_TOTAL_PHASE"`)



