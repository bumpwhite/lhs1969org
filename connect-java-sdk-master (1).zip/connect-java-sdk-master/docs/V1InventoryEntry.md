
# V1InventoryEntry

### Description

V1InventoryEntry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**variationId** | **String** | The variation that the entry corresponds to. |  [optional]
**quantityOnHand** | [**BigDecimal**](BigDecimal.md) | The current available quantity of the item variation. |  [optional]



