
# V1MerchantLocationDetails

### Description

Additional information for a single-location account specified by its associated business account, if it has one.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nickname** | **String** | The nickname assigned to the single-location account by the parent business. This value appears in the parent business&#39;s multi-location dashboard. |  [optional]



