
# V1TenderType

## Enum


* `CREDIT_CARD` (value: `"CREDIT_CARD"`)

* `CASH` (value: `"CASH"`)

* `THIRD_PARTY_CARD` (value: `"THIRD_PARTY_CARD"`)

* `NO_SALE` (value: `"NO_SALE"`)

* `SQUARE_WALLET` (value: `"SQUARE_WALLET"`)

* `SQUARE_GIFT_CARD` (value: `"SQUARE_GIFT_CARD"`)

* `UNKNOWN` (value: `"UNKNOWN"`)

* `OTHER` (value: `"OTHER"`)



