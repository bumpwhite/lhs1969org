
# Weekday

## Enum


* `MON` (value: `"MON"`)

* `TUE` (value: `"TUE"`)

* `WED` (value: `"WED"`)

* `THU` (value: `"THU"`)

* `FRI` (value: `"FRI"`)

* `SAT` (value: `"SAT"`)

* `SUN` (value: `"SUN"`)



