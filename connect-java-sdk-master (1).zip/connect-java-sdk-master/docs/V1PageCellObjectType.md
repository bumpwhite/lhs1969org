
# V1PageCellObjectType

## Enum


* `ITEM` (value: `"ITEM"`)

* `DISCOUNT` (value: `"DISCOUNT"`)

* `CATEGORY` (value: `"CATEGORY"`)

* `PLACEHOLDER` (value: `"PLACEHOLDER"`)



