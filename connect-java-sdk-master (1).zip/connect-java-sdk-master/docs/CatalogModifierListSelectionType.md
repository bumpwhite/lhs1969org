
# CatalogModifierListSelectionType

## Enum


* `SINGLE` (value: `"SINGLE"`)

* `MULTIPLE` (value: `"MULTIPLE"`)



