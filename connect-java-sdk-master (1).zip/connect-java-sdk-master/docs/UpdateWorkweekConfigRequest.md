
# UpdateWorkweekConfigRequest

### Description

A request to update a `WorkweekConfig` object

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**workweekConfig** | [**WorkweekConfig**](WorkweekConfig.md) | The updated &#x60;WorkweekConfig&#x60; object. |  [optional]



