
# OrderFulfillmentState

## Enum


* `PROPOSED` (value: `"PROPOSED"`)

* `RESERVED` (value: `"RESERVED"`)

* `PREPARED` (value: `"PREPARED"`)

* `COMPLETED` (value: `"COMPLETED"`)

* `CANCELED` (value: `"CANCELED"`)

* `FAILED` (value: `"FAILED"`)



