
# V1BankAccountType

## Enum


* `BUSINESS_CHECKING` (value: `"BUSINESS_CHECKING"`)

* `CHECKING` (value: `"CHECKING"`)

* `INVESTMENT` (value: `"INVESTMENT"`)

* `LOAN` (value: `"LOAN"`)

* `SAVINGS` (value: `"SAVINGS"`)

* `OTHER` (value: `"OTHER"`)



