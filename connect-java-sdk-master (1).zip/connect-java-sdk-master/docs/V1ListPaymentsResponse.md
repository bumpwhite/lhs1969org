
# V1ListPaymentsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Payment&gt;**](V1Payment.md) |  |  [optional]



