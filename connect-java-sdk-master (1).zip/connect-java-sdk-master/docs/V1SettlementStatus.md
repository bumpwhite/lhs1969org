
# V1SettlementStatus

## Enum


* `FAILED` (value: `"FAILED"`)

* `SENT` (value: `"SENT"`)



