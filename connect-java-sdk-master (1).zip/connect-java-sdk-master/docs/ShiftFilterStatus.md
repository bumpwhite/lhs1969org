
# ShiftFilterStatus

## Enum


* `OPEN` (value: `"OPEN"`)

* `CLOSED` (value: `"CLOSED"`)



