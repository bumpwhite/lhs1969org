
# V1ItemType

## Enum


* `NORMAL` (value: `"NORMAL"`)

* `GIFT_CARD` (value: `"GIFT_CARD"`)

* `OTHER` (value: `"OTHER"`)



