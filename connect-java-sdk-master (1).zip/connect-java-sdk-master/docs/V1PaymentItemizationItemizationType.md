
# V1PaymentItemizationItemizationType

## Enum


* `ITEM` (value: `"ITEM"`)

* `CUSTOM_AMOUNT` (value: `"CUSTOM_AMOUNT"`)

* `GIFT_CARD_ACTIVATION` (value: `"GIFT_CARD_ACTIVATION"`)

* `GIFT_CARD_RELOAD` (value: `"GIFT_CARD_RELOAD"`)

* `GIFT_CARD_UNKNOWN` (value: `"GIFT_CARD_UNKNOWN"`)

* `OTHER` (value: `"OTHER"`)



