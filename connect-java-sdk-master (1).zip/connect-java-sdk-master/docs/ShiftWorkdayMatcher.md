
# ShiftWorkdayMatcher

## Enum


* `START_AT` (value: `"START_AT"`)

* `END_AT` (value: `"END_AT"`)

* `INTERSECTION` (value: `"INTERSECTION"`)



