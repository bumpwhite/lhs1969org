
# V1FeeCalculationPhase

## Enum


* `FEE_SUBTOTAL_PHASE` (value: `"FEE_SUBTOTAL_PHASE"`)

* `OTHER` (value: `"OTHER"`)

* `FEE_TOTAL_PHASE` (value: `"FEE_TOTAL_PHASE"`)



