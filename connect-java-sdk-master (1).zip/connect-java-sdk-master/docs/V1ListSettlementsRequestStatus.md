
# V1ListSettlementsRequestStatus

## Enum


* `SENT` (value: `"SENT"`)

* `FAILED` (value: `"FAILED"`)



