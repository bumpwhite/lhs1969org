
# V1RetrieveCashDrawerShiftRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



