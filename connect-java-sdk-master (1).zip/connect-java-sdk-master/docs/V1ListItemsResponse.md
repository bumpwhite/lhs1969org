
# V1ListItemsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Item&gt;**](V1Item.md) |  |  [optional]



