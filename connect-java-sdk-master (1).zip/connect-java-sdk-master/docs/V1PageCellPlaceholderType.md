
# V1PageCellPlaceholderType

## Enum


* `ALL_ITEMS` (value: `"ALL_ITEMS"`)

* `DISCOUNTS_CATEGORY` (value: `"DISCOUNTS_CATEGORY"`)

* `REWARDS_FINDER` (value: `"REWARDS_FINDER"`)



