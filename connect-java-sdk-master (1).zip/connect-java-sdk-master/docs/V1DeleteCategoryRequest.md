
# V1DeleteCategoryRequest

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



