
# UpdateBreakTypeRequest

### Description

A request to update a `BreakType`

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**breakType** | [**BreakType**](BreakType.md) | The updated &#x60;BreakType&#x60;. |  [optional]



