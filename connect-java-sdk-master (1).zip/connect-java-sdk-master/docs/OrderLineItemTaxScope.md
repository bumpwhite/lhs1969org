
# OrderLineItemTaxScope

## Enum


* `OTHER_TAX_SCOPE` (value: `"OTHER_TAX_SCOPE"`)

* `LINE_ITEM` (value: `"LINE_ITEM"`)

* `ORDER` (value: `"ORDER"`)



