
# V1ListOrdersResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Order&gt;**](V1Order.md) |  |  [optional]



