
# TenderCardDetailsEntryMethod

## Enum


* `SWIPED` (value: `"SWIPED"`)

* `KEYED` (value: `"KEYED"`)

* `EMV` (value: `"EMV"`)

* `ON_FILE` (value: `"ON_FILE"`)

* `CONTACTLESS` (value: `"CONTACTLESS"`)



