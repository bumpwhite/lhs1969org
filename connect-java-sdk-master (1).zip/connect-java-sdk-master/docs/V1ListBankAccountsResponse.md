
# V1ListBankAccountsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1BankAccount&gt;**](V1BankAccount.md) |  |  [optional]



