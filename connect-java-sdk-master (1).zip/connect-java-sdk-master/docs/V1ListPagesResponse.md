
# V1ListPagesResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Page&gt;**](V1Page.md) |  |  [optional]



