
# DeleteBreakTypeRequest

### Description

A request to delete a `BreakType`

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



