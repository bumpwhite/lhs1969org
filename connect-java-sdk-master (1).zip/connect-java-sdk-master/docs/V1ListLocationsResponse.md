
# V1ListLocationsResponse

### Description



## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;V1Merchant&gt;**](V1Merchant.md) |  |  [optional]



