
# V1VariationInventoryAlertType

## Enum


* `LOW_QUANTITY` (value: `"LOW_QUANTITY"`)

* `NONE` (value: `"NONE"`)

* `INVESTMENT` (value: `"INVESTMENT"`)

* `LOAN` (value: `"LOAN"`)

* `SAVINGS` (value: `"SAVINGS"`)

* `OTHER` (value: `"OTHER"`)



