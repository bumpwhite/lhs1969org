
# V1FeeType

## Enum


* `CA_GST` (value: `"CA_GST"`)

* `CA_HST` (value: `"CA_HST"`)

* `CA_PST` (value: `"CA_PST"`)

* `CA_QST` (value: `"CA_QST"`)

* `JP_CONSUMPTION_TAX` (value: `"JP_CONSUMPTION_TAX"`)

* `CA_PEI_PST` (value: `"CA_PEI_PST"`)

* `US_SALES_TAX` (value: `"US_SALES_TAX"`)

* `OTHER` (value: `"OTHER"`)



