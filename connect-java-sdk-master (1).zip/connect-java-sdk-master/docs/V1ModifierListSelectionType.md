
# V1ModifierListSelectionType

## Enum


* `SINGLE` (value: `"SINGLE"`)

* `MULTIPLE` (value: `"MULTIPLE"`)



