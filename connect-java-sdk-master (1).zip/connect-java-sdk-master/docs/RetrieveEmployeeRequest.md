
# RetrieveEmployeeRequest

### Description

Retrieve an employee by `Employee.id`

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



